﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace WebApplication2
{
    public partial class Customer : System.Web.UI.Page
    {

        List<Person> people = new List<Person>();

        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {


                //Add data to display in gridview
                people.Add(new Person { Name = "John", Age = 20, Postcode = "E6 1AB", Height = 1.5 });
                people.Add(new Person { Name = "Jane", Age = 25, Postcode = "E6 3AB", Height = 1.0 });
                people.Add(new Person { Name = "Bob", Age = 30, Postcode = "E6 5AB", Height = 2.5 });

                //Bind the Data to the GridView
                GridView2.DataSource = people;
                GridView2.DataBind();
            }
        }

        protected void EditRow(object sender, GridViewEditEventArgs e)
        {
            GridView2.EditIndex = e.NewEditIndex;
            GridView2.DataSource = people;
            GridView2.DataBind();
        }

        protected void CancelEdit(object sender, GridViewCancelEditEventArgs e)
        {
            GridView2.EditIndex = -1;
            GridView2.DataSource = people;
            GridView2.DataBind();
        }

        protected void UpdateRow(object sender, GridViewUpdateEventArgs e)
        {
            int id = Convert.ToInt32(GridView2.DataKeys[e.RowIndex].Value);
            TextBox txtName = (TextBox)GridView2.Rows[e.RowIndex].FindControl("txtName");
            TextBox txtAge = (TextBox)GridView2.Rows[e.RowIndex].FindControl("txtAge");
            TextBox txtPostcode = (TextBox)GridView2.Rows[e.RowIndex].FindControl("txtPostcode");
            TextBox txtHeight = (TextBox)GridView2.Rows[e.RowIndex].FindControl("txtHeight");
            Person person = people.FirstOrDefault();
            person.Name = txtName.Text;
            person.Age = Convert.ToInt32(txtAge.Text);
            person.Postcode = txtPostcode.Text;
            person.Height = Convert.ToDouble(txtHeight.Text);

            GridView2.EditIndex = -1;
            GridView2.DataSource = people;
            GridView2.DataBind();
        }



        /* protected void AddRow(object sender, EventArgs e)
         {

             people.Add(new Person { Name = , Age = 0 });

             GridView2.DataSource = people;
             GridView2.DataBind();
         }
         */

        public class Person
        {
            public string Name { get; set; }
            public int Age { get; set; }
            public string Postcode { get; set; }
            public double Height { get; set; }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("AddCustomer.aspx");
        }

       
    }
}