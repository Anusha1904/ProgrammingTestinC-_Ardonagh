﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using static WebApplication2.Customer;

namespace WebApplication2
{
    public partial class AddCustomer : System.Web.UI.Page
    {
        List<Person> people = new List<Person>();
        protected void Page_Load(object sender, EventArgs e)
        {
            string name = Request.Form["name"];
            int age = Convert.ToInt32(Request.Form["age"]);
            string postcode = Request.Form["postcode"];
            double height = Convert.ToDouble(Request.Form["height"]);
            people.Add(new Person { Name = name, Age = age ,Postcode = postcode, Height = height});
            GridView1.DataSource = people;
            GridView1.DataBind();

        }
    }
}